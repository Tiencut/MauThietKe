State Pattern - Dien Thoai
Run file: ChuongTrinh.java