package vn.edu.husc.s_t1020761;

public class ChuongTrinh {

    public static void main(String[] args) {

        DienThoai dt =
                new DienThoai(new CheDoChuan());

        dt.setCheDo(new CheDoNgoaiTroi());

        dt.coTinNhanDen();

        dt.coThongBaoHeThong();

        dt.coCuocGoiDen();

        dt.setCheDo(new CheDoYenLang());

        dt.coTinNhanDen();

        dt.coCuocGoiDen();
    }
}
