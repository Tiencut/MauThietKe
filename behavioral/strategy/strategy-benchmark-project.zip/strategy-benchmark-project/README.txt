Project benchmark Strategy Pattern - Java
Run file: SortingBenchmark.java
