**Bài tập: Decorator Pattern — Trang trí Cafe**

**Mô tả đề**:
- Bài toán minh họa mẫu thiết kế Decorator (Trang trí) bằng ví dụ một tiệm cafe.
- Có một `component` cơ bản là `Cafe` (giao diện/ lớp trừu tượng) và một `CafeExpresso` là hiện thực cụ thể.
- Có lớp `TrangTriCafe` (decorator trừu tượng) dùng để mở rộng tính năng của `Cafe` tại thời điểm chạy.
- Các decorator cụ thể gồm `RhumTrangTriCafe` và `SuaTrangTriCafe` thêm mô tả và tăng giá thành.

**Mục tiêu**:
- Thực hành cách dùng Decorator để mở rộng hành vi đối tượng mà không cần thay đổi mã lớp gốc.

**Cấu trúc dự án (các file chính)**
- [DemoDecoratorPattern.java](dp4-tien-nguyenHuynhMinhTien/src/vn/edu/husc/dp4/nguyenHuynhMinhTien/DemoDecoratorPattern.java)
- [component/Cafe.java](dp4-tien-nguyenHuynhMinhTien/src/vn/edu/husc/dp4/nguyenHuynhMinhTien/component/Cafe.java)
- [component/CafeExpresso.java](dp4-tien-nguyenHuynhMinhTien/src/vn/edu/husc/dp4/nguyenHuynhMinhTien/component/CafeExpresso.java)
- [decorator/TrangTriCafe.java](dp4-tien-nguyenHuynhMinhTien/src/vn/edu/husc/dp4/nguyenHuynhMinhTien/decorator/TrangTriCafe.java)
- [decorator/RhumTrangTriCafe.java](dp4-tien-nguyenHuynhMinhTien/src/vn/edu/husc/dp4/nguyenHuynhMinhTien/decorator/RhumTrangTriCafe.java)
- [decorator/SuaTrangTriCafe.java](dp4-tien-nguyenHuynhMinhTien/src/vn/edu/husc/dp4/nguyenHuynhMinhTien/decorator/SuaTrangTriCafe.java)

**Cách biên dịch & chạy**
- Mở PowerShell ở thư mục chứa repo (hoặc thư mục cha của `dp4-tien-nguyenHuynhMinhTien`) rồi chạy:

```powershell
javac -d dp4-tien-nguyenHuynhMinhTien/out (Get-ChildItem -Path dp4-tien-nguyenHuynhMinhTien\src -Recurse -Filter *.java | ForEach-Object FullName)
java -cp dp4-tien-nguyenHuynhMinhTien/out vn.edu.husc.dp4.nguyenHuynhMinhTien.DemoDecoratorPattern
```

**Kết quả mong đợi**
- Cafe Expresso --> 15000.0
- Cafe Expresso + Rhum --> 16500.0
- Cafe Expresso + Rhum + Sua --> 17700.0

**Gợi ý mở rộng**
- Thêm nhiều decorator (ví dụ: Socola, Kem) và thử xếp thứ tự khác nhau để thấy ảnh hưởng lên mô tả/giá.
- Tạo script `build-and-run.ps1` hoặc thêm `build.gradle`/`pom.xml` để dễ biên dịch.

Nếu bạn muốn, tôi có thể tạo sẵn script chạy hoặc scaffold Gradle để tiện dùng.
